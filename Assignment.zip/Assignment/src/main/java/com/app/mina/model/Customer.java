package com.app.mina.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	private String customerId;

	private Timestamp createdDate;

	private Date dob;

	private String email;

	private String name;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	

}