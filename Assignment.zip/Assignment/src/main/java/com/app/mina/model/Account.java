package com.app.mina.model;

import java.io.Serializable;
import java.sql.Timestamp;


public class Account  implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer accountNumber;

	private double balance;

	private Timestamp createdDate;

	private Bank bank;
    private Customer customer;
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public Bank getBank() {
        return bank;
    }
    public void setBank(Bank bank) {
        this.bank = bank;
    }
	



	public Account() {
	}


	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}



    public Integer getAccountNumber() {
        return accountNumber;
    }


    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

	

}