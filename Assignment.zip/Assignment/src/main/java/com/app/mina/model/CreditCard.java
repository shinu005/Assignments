package com.app.mina.model;

import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the credit_card database table.
 * 
 */
public class CreditCard   implements Serializable {
    private static final long serialVersionUID = 1L;

    private StringBuilder cardNumber;
    private Date validity;
    private Double outstandingAmount;
    private Double maxLimit;
    private Bank bank;
    private Customer customer;
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public Bank getBank() {
        return bank;
    }
    public void setBank(Bank bank) {
        this.bank = bank;
    }
    public StringBuilder getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(StringBuilder cardNumber) {
        this.cardNumber = cardNumber;
    }

    public Date getValidity() {
        return validity;
    }

    public void setValidity(Date validity) {
        this.validity = validity;
    }

    public Double getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(Double outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    public Double getMaxLimit() {
        return maxLimit;
    }

    public void setMaxLimit(Double maxLimit) {
        this.maxLimit = maxLimit;
    }


}