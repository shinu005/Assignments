package com.app.mina.service;

import java.util.ArrayList;
import java.util.Scanner;

import com.app.mina.model.Account;
import com.app.mina.model.Customer;
import com.app.mina.model.Payment;
import com.app.mina.util.Utilities;

public class Assignment {
    static Scanner scan = new Scanner(System.in);
    static ArrayList<Payment> data = new ArrayList<Payment>();

    private static void setData() {

        String[] bankEventTypes = { "Payment", "Transaction" };
        Payment transaction = new Payment();
        Account account = new Account();
        Customer customer = new Customer();
        int eventType;

        account.setAccountNumber(Utilities.getIntData(scan, "Account number"));

        System.out.println("Please enter the name of account holder:");
        customer.setName(scan.nextLine());
        System.out.println("Please enter the text ");
        transaction.setText(scan.nextLine());

        eventType = Utilities.getIntData(scan,
            "Bank Event ,\n Type 1 for Payment 2 for Transaction");
        if (eventType == 1) {
            System.out.println("Please enter the reciept number ");
            transaction.setRecipientNumber(scan.next().toString());
        }
        transaction.setAmount(Utilities.getIntData(scan, "Amount"));

        transaction.setTransactionDate(Utilities.getDateData(scan,
            "transaction date (YYYY-MM-DD format)"));
        transaction.setEventType(bankEventTypes[eventType - 1]);
        account.setCustomer(customer);
        transaction.setAccount(account);
        System.out.println(transaction);
        data.add(transaction);
        Utilities.writeData(data);
        for (int i = 0; i < data.size(); i++) {
            System.out.println(data.get(i));
        }
    }

    public static void main(String[] args) {

        TransactionService tService = new TransactionService();

        System.out
            .println("****************************************************");
        System.out.println(
            "[ Options: 1 (Give several bank accounts with their bank events as input,removes all bank account transactions"
                + " with a positive amount and outputs only the bank accounts that still have at least one event, also return the"
                + " remaining events in the output.)]");
        System.out.println(
            "[ Options: 2 (function that calculates the balance of a bank account or credit card.  )]");
        System.out.println(
            "[Options: 3 (Function to detect the time interval Weekly group (by text))]");
        System.out.println(
                "[Options: 4 (Function to detect the time interval Monthly group (by text))]");

        System.out
            .println("[Options: 5 (To enter the transaction/Payment data]");
        System.out.println("[Exit : 6 ]");

        System.out
            .println("****************************************************");
        System.out.println("Enter the option for the operation you need:");

        switch (scan.nextInt()) {
        case 1:
            tService.getTransactionDetails(Utilities.readData());
            break;
        case 2:
            tService.calculateBalance(Utilities.readData());
            break;
        case 3:

            tService.getBiWeeklyEvents(Utilities.readData());
            break;
        case 4:

            tService.getMonthlyEvents(Utilities.readData());
            break;
        case 5:

            StringBuilder newRecords = null;
            boolean done = false;
            char option = 'Y';
            do {

                if (newRecords != null) {
                    option = newRecords.charAt(0);
                }
                if (option == 'N' || option == 'n') {
                    System.out.println("Exiting");
                    done = true;
                } else {
                    setData();
                    System.out
                        .println("Do you want to enter new record (Y/N)???");
                    newRecords = new StringBuilder(scan.next());
                    done = false;
                }
            } while (!done);
            break;
        default:
            System.out.println("Thank You. Visit Again!");
            scan.close();
            System.exit(0);
            break;

        }
    }

}
