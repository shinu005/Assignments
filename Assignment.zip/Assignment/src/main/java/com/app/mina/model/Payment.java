package com.app.mina.model;

import java.text.SimpleDateFormat;

public class Payment extends Transaction {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String recipientNumber;

    public String getRecipientNumber() {
        return recipientNumber;
    }

    public void setRecipientNumber(String recipientNumber) {
        this.recipientNumber = recipientNumber;
    }

    public String toString() {// overriding the toString() method
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return  dateFormat.format(this.getTransactionDate())+ "               " + this.getText() + "               "
            + this.getEventType() + "               "
            + this.getRecipientNumber() + "               "
            + this.getAmount();
    }

}
