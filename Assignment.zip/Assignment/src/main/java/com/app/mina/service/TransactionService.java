package com.app.mina.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.app.mina.model.Payment;
import com.app.mina.util.Utilities;

public class TransactionService {
    final static String SPACING10 = "          ";
    final static String SPACING5 = "     ";
    final static String SPACING2 = "  ";

    /*
     * Create a function that given several bank accounts with their bank events
     * as input, removes all bank account transactions with a positive amount
     * and outputs only the bank accounts that still have at least one event,
     * also return the remaining events in the output.
     */
    public Map<Integer, List<Payment>> getTransactionDetails(
        List<Payment> trans) {
        SimpleDateFormat format = new SimpleDateFormat("YYYY-MMM-dd");

        Map<Integer, List<Payment>> accountAndTransactionDetails =
            new HashMap<Integer, List<Payment>>();
        List<Payment> transList = new ArrayList<Payment>();
        for (Payment payment : trans) {
            if (payment.getAmount() < 0) {
                if (accountAndTransactionDetails
                    .get(payment.getAccount().getAccountNumber()) != null) {
                    transList = accountAndTransactionDetails
                        .get(payment.getAccount().getAccountNumber());
                } else {
                    transList = new ArrayList<Payment>();
                }
                transList.add(payment);
                accountAndTransactionDetails
                    .put(payment.getAccount().getAccountNumber(), transList);
            }

        }
        Iterator<Map.Entry<Integer, List<Payment>>> entries =
            accountAndTransactionDetails.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, List<Payment>> entry = entries.next();
            System.out.println(
                "******************************************************************************************");
            System.out.println("Account # " + entry.getKey());
            System.out.println("Date" + SPACING10 + SPACING5 + "Bank event type"
                + SPACING10 + "Amount" + SPACING10 + "Text");
            transList = entry.getValue();
            for (Payment payment : transList) {

                System.out.print(format.format(payment.getTransactionDate())
                    + SPACING10 + payment.getEventType() + SPACING10);
                if (payment.getEventType().equals("Payment")) {
                    System.out.print(SPACING5);
                } else {
                    System.out.print(SPACING2);
                }
                System.out.println(
                    payment.getAmount() + SPACING10 + payment.getText());
            }
            System.out.println(
                "******************************************************************************************");
        }
        return accountAndTransactionDetails;
    }

    public Map<Integer, Double> calculateBalance(List<Payment> trans) {
        Map<Integer, List<Payment>> accountAndTransactionDetails =
            Utilities.createMapWithAccount(trans);

        Map<Integer, Double> acountBalanceMap = new HashMap<Integer, Double>();
        Iterator<Map.Entry<Integer, List<Payment>>> entries =
            accountAndTransactionDetails.entrySet().iterator();
        while (entries.hasNext()) {
            double balanceAount = 0.0;

            Map.Entry<Integer, List<Payment>> entry = entries.next();
            Integer key = entry.getKey();
            System.out.println("Account # " + key);
            Payment[] transactions =
                entry.getValue().toArray(new Payment[entry.getValue().size()]);
            for (Payment payment : transactions) {
                balanceAount += payment.getAmount();
            }
            System.out.println("Balance # " + balanceAount);
            System.out.println(
                "******************************************************************");
            acountBalanceMap.put(key, balanceAount);
        }
        return acountBalanceMap;
    }

    public Map<Integer, List<List<Payment>>> getBiWeeklyEvents(List<Payment> trans) {
        Map<Integer, List<List<Payment>>> weeklyList =
                new HashMap<Integer, List<List<Payment>>>();
        Map<Integer, List<Payment>> accountAndTransactionDetails =
            Utilities.createMapWithAccount(trans);
        Iterator<Map.Entry<Integer, List<Payment>>> entries =
            accountAndTransactionDetails.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, List<Payment>> entry = entries.next();
            Payment[] transactions =
                entry.getValue().toArray(new Payment[entry.getValue().size()]);
            for (int i = 0; i < transactions.length; i++) {
                List<List<Payment>> listOfListOfPayments =
                        new ArrayList<List<Payment>>();
                for (int j = i + 1; j < transactions.length; j++) {
                    if (transactions[i].getText()
                        .equalsIgnoreCase(transactions[j].getText())) {
                        int dateDiff = Utilities.getTimeDiff(
                            transactions[i].getTransactionDate(),
                            transactions[j].getTransactionDate());
                        if (dateDiff == 14) {
                            List<Payment> list = new ArrayList<Payment>();
                            System.out.println("Weekly Transaction");
                            System.out.println("**********************");
                            System.out.println(
                                transactions[i].getAccount().getAccountNumber()
                                    + "    " + transactions[i].getAmount()
                                    + "    " + transactions[i].getText() + "   "
                                    + transactions[i].getTransactionDate());
                            System.out.println(
                                transactions[j].getAccount().getAccountNumber()
                                    + "    " + transactions[j].getAmount()
                                    + "    " + transactions[j].getText() + "   "
                                    + transactions[j].getTransactionDate());

                            System.out.println("**********************");
                            list.add(transactions[j]);
                            list.add(transactions[i]);
                            listOfListOfPayments.add(list);
                            weeklyList.put(
                                transactions[i].getAccount().getAccountNumber(),
                                listOfListOfPayments);
                        }
                    }
                }
            }
        }
        return weeklyList;
    }

    public Map<Integer, List<List<Payment>>> getMonthlyEvents(
        List<Payment> trans) {
        Map<Integer, List<List<Payment>>> monthlyList =
            new HashMap<Integer, List<List<Payment>>>();
        Map<Integer, List<Payment>> accountAndTransactionDetails =
            Utilities.createMapWithAccount(trans);
        Iterator<Map.Entry<Integer, List<Payment>>> entries =
            accountAndTransactionDetails.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, List<Payment>> entry = entries.next();
            Payment[] transactions =
                entry.getValue().toArray(new Payment[entry.getValue().size()]);
            for (int i = 0; i < transactions.length; i++) {
                List<List<Payment>> lsitOfListOfPayments =
                    new ArrayList<List<Payment>>();
                for (int j = i + 1; j < transactions.length; j++) {
                    if (transactions[i].getText()
                        .equalsIgnoreCase(transactions[j].getText())) {
                        int dateDiff = Utilities.getTimeDiff(
                            transactions[i].getTransactionDate(),
                            transactions[j].getTransactionDate());
                        if (dateDiff == 30 || dateDiff == 31) {
                            List<Payment> lsit = new ArrayList<Payment>();
                            System.out.println("Monthly Transaction");
                            System.out.println("**********************");
                            System.out.println(
                                transactions[i].getAccount().getAccountNumber()
                                    + "    " + transactions[i].getAmount()
                                    + "    " + transactions[i].getText() + "   "
                                    + transactions[i].getTransactionDate());
                            System.out.println(
                                transactions[j].getAccount().getAccountNumber()
                                    + "    " + transactions[j].getAmount()
                                    + "    " + transactions[j].getText() + "   "
                                    + transactions[j].getTransactionDate());

                            System.out.println("**********************");
                            lsit.add(transactions[j]);
                            lsit.add(transactions[i]);
                            lsitOfListOfPayments.add(lsit);
                            monthlyList.put(
                                transactions[i].getAccount().getAccountNumber(),
                                lsitOfListOfPayments);
                        }
                    }
                }
            }
        }
        return monthlyList;
    }

}
