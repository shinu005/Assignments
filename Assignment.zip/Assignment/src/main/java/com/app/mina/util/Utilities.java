package com.app.mina.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import com.app.mina.model.Payment;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Utilities {
    public static void writeData(ArrayList<Payment> transactions) {
        ObjectMapper mapper = new ObjectMapper();

        try {
            mapper.writeValue(new File("/account_transaction.json"), transactions);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Payment> readData() {
        ObjectMapper mapper = new ObjectMapper();
        List<Payment> transList = null;
        try {
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            Payment[] transactions =
                mapper.readValue(new File("/account_transaction.json"), Payment[].class);
            transList = new ArrayList<Payment>(Arrays.asList(transactions));
        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return transList;
    }

    public static int getIntData(Scanner scanner, String type) {
        System.out.println("Please enter the " + type + " :");
        int result = 0;
        boolean done = true;
        boolean retry = false;
        do {
            if (retry) {
                System.out.println("You have enterd invalid " + type
                    + ". Please enter a valid " + type + " :");
            }
            try {
                result = Integer.parseInt(scanner.next());
                done = true;
            } catch (NumberFormatException e) {
                done = false;
                retry = true;
            }
        } while (!done);

        return result;
    }

    public static Date getDateData(Scanner scanner, String type) {
        System.out.println("Please enter the " + type + " :");
        Date result = null;
        boolean done = true;
        boolean retry = false;
        do {
            if (retry) {
                System.out.println("You have enterd invalid " + type
                    + ". Please enter a valid " + type + " :");
            }
            try {
                result =
                    new SimpleDateFormat("yyyy-MM-dd").parse(scanner.next());
                done = true;
            } catch (Exception e) {
                done = false;
                retry = true;
            }
        } while (!done);

        return result;
    }

    public static double getDoubleData(Scanner scanner, String type) {
        System.out.println("Please enter the " + type + " :");
        double result = 0.0;
        boolean done = true;
        boolean retry = false;
        do {
            if (retry) {
                System.out.println("You have enterd invalid " + type
                    + ". Please enter a valid " + type + " :");
            }
            try {
                result = Double.parseDouble(scanner.next());
                done = true;
            } catch (NumberFormatException e) {
                done = true;
                retry = true;
            }
        } while (!done);

        return result;
    }

    public static boolean validateDate(String data) {
        try {
            Integer.parseInt(data);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
    
    public static int getTimeDiff(Date dateOne, Date dateTwo) {
        int diff = 0;
        long timeDiff = Math.abs(dateOne.getTime() - dateTwo.getTime());
        diff = (int) TimeUnit.MILLISECONDS.toDays(timeDiff);
        return diff;
    }
    public static Map<Integer, List<Payment>> createMapWithAccount(
        List<Payment> trans) {
        Map<Integer, List<Payment>> accountAndTransactionDetails =
            new HashMap<Integer, List<Payment>>();
        List<Payment> transList = new ArrayList<Payment>();
        for (Payment payment : trans) {
            if (accountAndTransactionDetails
                .get(payment.getAccount().getAccountNumber()) != null) {
                transList = accountAndTransactionDetails
                    .get(payment.getAccount().getAccountNumber());
            } else {
                transList = new ArrayList<Payment>();
            }
            transList.add(payment);
            accountAndTransactionDetails
                .put(payment.getAccount().getAccountNumber(), transList);

        }
        return accountAndTransactionDetails;
    }
}
