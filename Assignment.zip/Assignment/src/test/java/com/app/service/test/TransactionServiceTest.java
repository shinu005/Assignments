package com.app.service.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.app.mina.model.Account;
import com.app.mina.model.Payment;
import com.app.mina.service.TransactionService;

public class TransactionServiceTest {
    ArrayList<Payment> transList;

    @Before
    public void initialize() {
        transList = new ArrayList<Payment>();
        Payment payment = null;

        payment = new Payment();
        Account account = new Account();
        account.setAccountNumber(1000);
        payment.setAmount(-100);
        payment.setText("Gym");
        payment.setEventType("Payment");
        payment.setRecipientNumber("123-456");
        payment.setAccount(account);
        try {
            payment.setTransactionDate(
                new SimpleDateFormat("yyyy-MM-dd").parse("2017-01-01"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        transList.add(payment);

        payment = new Payment();
        account = new Account();
        account.setAccountNumber(1000);
        payment.setAmount(500);
        payment.setText("Salary");
        payment.setEventType("Transaction");

        payment.setAccount(account);
        try {
            payment.setTransactionDate(
                new SimpleDateFormat("yyyy-MM-dd").parse("2017-01-01"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        transList.add(payment);
        payment = new Payment();
        account = new Account();
        account.setAccountNumber(1000);
        payment.setAmount(-100);
        payment.setText("Gym");
        payment.setEventType("Payment");
        payment.setRecipientNumber("123-456");
        payment.setAccount(account);
        try {
            payment.setTransactionDate(
                new SimpleDateFormat("yyyy-MM-dd").parse("2017-02-01"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        transList.add(payment);
    }

    @Test

    public void testCalculateBalance1() {
        TransactionService testService = new TransactionService();
        Map<Integer, Double> acountBalanceMap =
            testService.calculateBalance(transList);
        assertNotNull("CalculateBalance Unit testeing done",
            acountBalanceMap.get(1000));
    }

    @Test

    public void testCalculateBalance2() {
        TransactionService testService = new TransactionService();
        Map<Integer, Double> acountBalanceMap =
            testService.calculateBalance(transList);
        assertTrue(acountBalanceMap.get(1000) == 300.00);
    }

    @Test

    public void testGetTransactionDetails() {
        TransactionService testService = new TransactionService();
        Map<Integer, List<Payment>> acountDetailsMap =
            testService.getTransactionDetails(transList);
        assertNotNull("GetTransactionDetails Unit testeing done",
            acountDetailsMap.get(1000));
    }

    @Test

    public void testGetTransactionDetails2() {
        TransactionService testService = new TransactionService();
        Map<Integer, List<Payment>> acountDetailsMap =
            testService.getTransactionDetails(transList);
        assertTrue(!acountDetailsMap.keySet().isEmpty());
    }
}
