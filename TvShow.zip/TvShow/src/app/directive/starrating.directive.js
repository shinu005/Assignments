angular.module('tvshow').directive('starRating', function (ParamService,$timeout) {
    return {
        scope: {
            rating: '=',
            maxRating: '@',
            readOnly: '@',
            click: "&",
            mouseHover: "&",
            mouseLeave: "&",
            halfRating: '@'
        },
        restrict: 'EA',
        template:
            "<div style='display: inline-block; margin: 0px; padding: 0px; cursor:pointer;' text='maxRatings' ng-repeat='idx in maxRatings track by $index'> \
                    <img ng-src='{{(( _rating) <= $index) && \"../app/icon/star-empty-lg.png\" || \"../app/icon/star-1.png\"}}' \
                    ng-Click='isolatedClick($index + 1)' \
                    ng-mouseenter='isolatedMouseHover($index + 1)' \
                    ng-mouseleave='isolatedMouseLeave($index + 1)'></img> \
                     \
                                 </div><img ng-if='hRating' ng-src=' ../app/icon/star-2.png' \
                                 </div><img ng-if='oRating' ng-src=' ../app/icon/star-3.png' \
                                 </div><img ng-if='qRating' ng-src=' ../app/icon/star-4.png' \
                    </img>",
        compile: function (element, attrs) {
            if (!attrs.maxRating || (Number(attrs.maxRating) <= 0)) {
                attrs.maxRating = '5';
            }
        },
        link: function($scope, $element, $attrs) {
          $scope.$watch($attrs.rating,function(newValue,oldValue){
                if (newValue!=oldValue){           
                    $scope.rating=newValue;
                 }
            });
        },
        controller: function ($scope, $element, $attrs) {
            //loadStar();
            var loadStar = function(){
           $timeout(function() { 
                $scope.maxRatings=[];
                
                $scope.$watch($attrs.rating,function(newValue,oldValue){
                     if (newValue!=oldValue){           
                        $scope.rating=newValue;
                     }
                });

                for (var i = 1; i <= $scope.rating; i++) {
                    $scope.maxRatings.push({});
                }
                var decimalValue=$scope.rating-parseInt($scope.rating);
                if(decimalValue>=.75){
                     $scope.hRating=false;
                     $scope.qRating=false;
                     $scope.oRating=true;
                }else  if(decimalValue>=.5){
                    $scope.hRating=true;
                     $scope.qRating=false;
                     $scope.oRating=false;
                }else  if(decimalValue>=.25){
                    $scope.hRating=false;
                     $scope.qRating=true;
                     $scope.oRating=false;
                }else{
                    $scope.hRating=false;
                     $scope.qRating=false;
                     $scope.oRating=false;
                }
                $scope._rating = $scope.rating;
               
            }, 500);
           
       };
        $scope.$watch($attrs.rating,function(newValue,oldValue){
                     if (newValue!=oldValue){           
                        $scope.rating=newValue;
                        loadStar();
                     }
                });
            
        }
    };
});