(function() {
  'use strict';

  angular
    .module('tvshow')
    .config(routerConfig);

  /** @ngInject */
  function routerConfig($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('/home', {
        cache: false,
        url: '/',
        templateUrl: 'app/main/template/main.html',
        controller: 'MainController',
        controllerAs : 'detail'
      });

    $urlRouterProvider.otherwise('/');
  }

})();
