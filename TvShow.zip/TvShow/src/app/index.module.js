(function() {
  'use strict';

  angular
    .module('tvshow', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize',
     'ngMessages', 'ngAria', 'ngResource', 'ui.router', 'ui.bootstrap', 'toastr']);

})();
