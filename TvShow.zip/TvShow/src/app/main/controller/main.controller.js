'use strict';
angular.module('tvshow').controller('MainController', function ($scope,$timeout,MainService,ParamService) {

	$scope.tvShowName="Silicon Valley";
	$scope.season='1'
	$scope.searchKey;
	$scope.detail={};
	searchTvShow();

	function searchTvShow() {
		ParamService.setParam($scope.tvShowName);
		ParamService.setSearchParamType('t');
		ParamService.setSeason($scope.season);
		$scope.detail={}
		//ParamService.setRating(5);

		$scope.rating = 1;
		//$scope.rating2 = 10;
		$scope.isReadonly = false;
		
		MainService.fetchTvData()
			.then(
				function(response){
					$scope.detail= response;
					$scope.status='success';
					$scope.starRating1=response.avgRating;
					$scope.rating = parseFloat(response.avgRating);
					$scope.rating =  parseFloat(response.avgRating);
					ParamService.setData($scope.detail);
					$scope.missionCompled=true;
					//console.log(JSON.stringify($scope.detail))
				},
				function(errResponse){
					$scope.detail=errResponse;
				});
			}
			$scope.sortBy = function(propertyName) {
					$scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
					$scope.propertyName = propertyName;
			};

			$scope.remove =function (id){
				$scope.detail = ParamService.getData();
				angular.forEach($scope.detail.Episodes, function(episode){
				if(episode.imdbID==id){
					episode.show=(!episode.show);
					return false;         
				}
				});
				ParamService.setData($scope.detail);
			};

			$scope.search =function (){
			
				searchTvShow();
			}


});
