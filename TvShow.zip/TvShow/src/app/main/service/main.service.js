'use strict';

angular.module('tvshow').service('MainService', 
 function($http, $q,APIService,$log,$filter,ParamService){
    this.fetchTvData= function () {

       
        var deferred = $q.defer();
        var ratingAvg=0;
        var ratingSum=0;
        var episodeCount=0;
        var seasonsArray=[];
       APIService.fetchTvData()
            .then(
                function (response) {
                    angular.forEach(response.Episodes, function(episode){
                        if(!isNaN(parseFloat(episode.imdbRating))){
                             ratingSum+=parseFloat(episode.imdbRating);
                        }
                         ParamService.setSearchParamType('i');
                         ParamService.setParam(episode.imdbID);
                         APIService.fetchTvData()
                            .then(
                                function (response) {
                                    episode['details']=response;
                                    episode['show']=true;
                                },
                                function(errResponse){
                                    deferred.reject(errResponse);
                                }
                            );
                        episodeCount++;
                     });
                     for(var i=0;i<response.totalSeasons;i++){
                        seasonsArray.push(i+1);
                     }
                    response['seasonsArray']=seasonsArray;
                    ratingAvg = $filter('number')((ratingSum/episodeCount), 2);
                    ParamService.setRating(10);
                 response['avgRating']=ratingAvg;
                 if(response.Response=='True'){
                     response['success']=true;
                 }else{
                        response['success']=false;
                 }

                deferred.resolve(response);
            },
            function(errResponse){
                 errResponse['success']=false;
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

   

});
