'use strict';
angular.module('tvshow').service('ParamService', function () {
    this.selectedShowNames = [];
    this.searchParamType=undefined;
    this.param=undefined;
    this.season=0;
    this.rating=1;
    this.data={};

    this.setData = function(data){
      this.data = data;
    };
    
    this.getData = function() {
      return this.data;
    };
    this.setParam = function(param){
      this.param = param;
    };
    
    this.getParam = function() {
      return this.param;
    };
    this.setRating = function(rating){
      this.rating = rating;
    };
    
    this.getRating = function() {
      return this.rating;
    };
    this.setSeason = function(season){
      this.season = season;
    };
    
    this.getSeason = function() {
      return this.season;
    };
    this.setSearchParamType = function(searchParamType){
      this.searchParamType = searchParamType;
    };
    
    this.getSearchParamType = function() {
      return this.searchParamType;
    };
   
    
    this.reset = function(){
      this.param = undefined;
      this.selectedShowNames = [];
      this.searchParamType=undefined;
      this.param=undefined;
      this.season=0;
      this.rating=0;
    };
});