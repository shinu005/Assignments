'use strict';

angular.module('tvshow').factory('APIService',  function($http, $q,ParamService){

    var REST_SERVICE_URI = 'https://www.omdbapi.com/';

    var factory = {
        fetchTvData: fetchTvData
    };

    return factory;

    function fetchTvData() {
        var deferred = $q.defer();
        var requestUrl=REST_SERVICE_URI;
        if(ParamService.getSearchParamType()==='i'){
            requestUrl+='?'+ParamService.getSearchParamType()+'='+ParamService.getParam();
        }else{
            if(ParamService.getSeason()===0){
                requestUrl+='?'+ParamService.getSearchParamType()+'='+ParamService.getParam();
            }else{
                requestUrl+='?'+ParamService.getSearchParamType()+'='+ParamService.getParam()+'&Season='+ParamService.getSeason();
            }
        }

        $http({
        method: 'GET',
        url: requestUrl,
        async: false
        })
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

   

});
